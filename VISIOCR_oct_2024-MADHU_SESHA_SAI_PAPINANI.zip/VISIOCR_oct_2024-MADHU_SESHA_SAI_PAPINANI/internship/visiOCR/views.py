from django.shortcuts import render
from PIL import Image
import pytesseract
import re
from datetime import datetime
from .models import *
import qrcode
import io
import base64




pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def generate_qrcode(info):
    # Generate QR code content
    qr_content = f"Name: {info['name']}, DOB: {info['dob']}, Date:{info['date']},Time:{info['time']}"
    qr = qrcode.make(qr_content)
    buffer = io.BytesIO()
    qr.save(buffer, format="PNG")
    buffer.seek(0)
    qr_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return qr_base64



def text_extraction(image):
    extracted_text = pytesseract.image_to_string(image )
    return extracted_text
def aadhar_extraction(text):
    # Regex to capture name (Name: typically before DOB)
    name_pattern = re.compile(r'\b[A-Za-z][A-Za-z\s]*[A-Za-z]\b')
    # Regex to capture DOB in DD/MM/YYYY or similar formats
    dob_pattern = re.compile(r'DOB\s*:\s*\d{2}[/-]\d{2}[/-]\d{4}')
    dob=""
    name=""
    for line in text:
        if len(line)>7 and 'Q' not in line and 'Date' not in line and not any(chr.isdigit() for chr in line):
            name=name_pattern.findall(line)
        if name and len(name[0])>=7:
            break
    for line in text:
        if 'DOB'  in line :
            dob=dob_pattern.findall(line)
            break
    if name and dob:
        return (name[0],dob[0][5:])
    else:
        return([],[])
def pan_extraction(text):
    # Regex to capture name (Name: typically before DOB)
    name_pattern = re.compile(r'\b[A-Za-z][A-Za-z\s]*[A-Za-z]\b')
    # Regex to capture DOB in DD/MM/YYYY or similar formats
    date_pattern = r'\b\d{2}/\d{2}/\d{4}\b'
    name=""
    dob=""
    for line in range(len(text)):
        if  'Name' in text[line]:
            name=name_pattern.findall(text[line+1])
            break
        
    for line in text:
        dob = re.findall(date_pattern, line)
        if dob:
            return (name[0],dob[0])
    return ([],[])

# Create your views here.
def main(request):
    if request.method=='POST':
        data=request.POST
        image_path=request.FILES.get('image')
        print(type(image_path))
        image = Image.open(image_path)
        text=text_extraction(image)
        if 'Permesent Account number Card' in text:
            name,dob=pan_extraction(text.split('\n'))
            card="PAN"
           
        else:
            name,dob=aadhar_extraction(text.split('\n'))
            card="AADHAR"
        if name and dob:
            now = datetime.now()
            date= now.strftime("%Y-%m-%d %H:%M:%S")
            c_date=date[:10]
            c_time=date[11:]
            
            Data.objects.create(
                u_name=name,
                u_don=dob,
                card=card,
                date=c_date,
                time=c_time,

            )
            info={
                'name':name,
                'dob':dob,
                'card':card,
                'date':c_date,
                'time':c_time,
            }
            qr=generate_qrcode(info)

        return render(request,'pass.html' ,context={'data':info,'qr_code':qr})

    return render(request,'home.html')






    
