from django.db import models

# Create your models here.
class Data(models.Model):
    u_name=models.CharField(max_length=30)
    u_don=models.CharField(max_length=30)
    card=models.CharField(max_length=10)
    date=models.DateField()
    time=models.TimeField()


